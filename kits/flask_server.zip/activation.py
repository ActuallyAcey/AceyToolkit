from os import system, path, getcwd
import subprocess

system('cls')
print(f"Activation script for new Flask Server now running. \nThis file will automatically delete itself once the project is ready.")
print("\nInitializing virtual environment...")

system(f'virtualenv -q "{path.dirname(__file__)}\\env"')
print("Installing dependencies...")
subprocess.Popen([
    f"{path.dirname(__file__)}/env/Scripts/python.exe", "-m", "pip", "install", "-q", "-r", 
    f"{path.dirname(__file__)}/requirements.txt"], shell=True).wait()

print("Virtual environment successfully built.")

print("Create git repository?")
if (input().lower() == 'n'):
    pass
else:
    subprocess.Popen(["git","init",f"{path.dirname(__file__)}"], shell=True).wait()

    print("Local repo successfully created.")

print("Project now ready!")
input()