from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from flask_ngrok import run_with_ngrok
# from flask_pymongo import PyMongo

import server_secrets

app = Flask(__name__)

# == testing ==
run_with_ngrok(app)
CORS(app)

# == config ==
app.url_map.strict_slashes = False
# app.config['MONGO_DBNAME'] = server_secrets.mongo_db_name
# app.config['MONGO_URI'] = server_secrets.mongo_uri

# == routes ==
@app.route('/', methods = ['GET'])
def get_data():
    return send_from_directory(app.root_path, 'test.json')

@app.route('/', methods = ['POST'])
def push_data():
    try:
        data = request.get_json()
        print(data)
        return jsonify({"Message": "Done"})

    except (e):
        return jsonify({"Message": str(e)})

if __name__ == '__main__':
    app.run()