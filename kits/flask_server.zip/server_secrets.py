VALUE1 = 12345
VALUE2 = "Some string value."
VALUE3 = ["Thing 1", "Thing 2", "Thing 3"]